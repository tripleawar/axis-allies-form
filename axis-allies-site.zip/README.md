# Axis & Allies Game Submission Form
This is a static HTML form to record game results.